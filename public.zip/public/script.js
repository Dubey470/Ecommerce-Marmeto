// Simulate clicking on the "Add to Cart" button
function addToCart() {
  var addToCartButton = document.querySelector('#add-to-cart-button');
  addToCartButton.click();
}

// Simulate selecting a color
function selectColor(color) {
  var colorSelect = document.querySelector('#color-select');
  colorSelect.value = color;
  colorSelect.dispatchEvent(new Event('change'));
}

// Simulate selecting a size
function selectSize(size) {
  var sizeSelect = document.querySelector('#size-select');
  sizeSelect.value = size;
  sizeSelect.dispatchEvent(new Event('change'));
}

// Example usage
addToCart();
selectColor('yellow');
selectSize('small');